from django.apps import AppConfig


class ShoppingpageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shoppingpage'
