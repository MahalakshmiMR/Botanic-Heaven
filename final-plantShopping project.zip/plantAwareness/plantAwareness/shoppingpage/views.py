from django.shortcuts import redirect, render
from django.contrib.auth.models import User,auth
import mysql.connector 

# Create your views here.
 

def homepage(request):
    if request.method == 'POST':
        return redirect('/accounts/home')
            
    else:
        return render(request,'homepage.html')

def shoppingpage(request):
    if request.method == 'POST':
        return redirect('/accounts/payment')
            
    else:
        return render(request,'shoppingpage.html')

def AboutUs(request):
       return render(request,'AboutUs.html')

def Awareness(request):
       return render(request,'Awareness.html')

   




