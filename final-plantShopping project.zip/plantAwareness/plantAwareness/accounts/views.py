from django.shortcuts import redirect, render
from django.contrib.auth.models import User,auth
import mysql.connector 



# Create your views here.
firstName=''
lastName=''
userName=''
email=''
password=''
password2=''

CardHolderName=''
CardNumber=''
CardExpDate=''
Amount=''

phone=''
ExplainYourConcern=''
userName=''



def accounts(request):
    return render(request,'accounts.html')

def login(request):

    global userName,password
    if request.method=="POST":
        userName=request.POST['user_name']
        password=request.POST['password']

        user = auth.authenticate(username=userName,password=password)

        if user is not None:
            auth.login(request,user)
            print("User is Logged in")
            return redirect('/')
        m=mysql.connector.connect(host="localhost",user="root",passwd="root@2201",database='leaf')
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
            if key=="user_name":
                userName=value
            if key=="password":
                password=value
        
        c="select * from signup where userName='{}' and password='{}' ".format(userName,password)
        cursor.execute(c)

        t=tuple(cursor.fetchall())
        if t==():
            return render(request,'error.html')
        else:
            return redirect('/shoppingpage')
       
    return render(request,'login.html')
        


        

       

    

def signup(request):
   
    global firstName,lastName,userName,email,password,password2
    if request.method == 'POST':

        
            m=mysql.connector.connect(host="localhost",user="root",passwd="root@2201",database='leaf',autocommit=True)
            cursor=m.cursor()
            d=request.POST
            
            firstName=request.POST['first_name']
            lastName=request.POST['last_name']
            userName=request.POST['user_name']
            email=request.POST['email']
            password=request.POST['password']
            password2=request.POST['password2']
            if password==password2:
                user = User.objects.create_user(username=userName,email=email,password=password,first_name=firstName,last_name=lastName)
            for key,value in d.items():
                if key=="first_name":
                    firstName=value
                if key=="last_name":
                    lastName=value
                if key=="user_name":
                    userName=value
                if key=="email":
                    email=value
                if key=="password":
                    password=value
                if key=="password2":
                    password2=value


            if password==password2:
                c="insert into signup Values('{}','{}','{}','{}','{}','{}')".format(firstName,lastName,userName,email,password,password2)
                cursor.execute(c)
                m.commit()
                return redirect('/shoppingpage')
            

                
            else:
                return render(request,'passwdmismatch.html')
                
        

    return render(request,'signup.html')  



def payment(request):
   
    global CardHolderName,CardNumber,CardExpDate,Amount
    if request.method == 'POST':

        
            m=mysql.connector.connect(host="localhost",user="root",passwd="root@2201",database='leaf',autocommit=True)
            cursor=m.cursor()
            d=request.POST
            
            CardHolderName=request.POST['CardHolder_name']
            CardNumber=request.POST['Card_number']
            CardExpDate=request.POST['CardExp_Date']
            Amount=request.POST['Amount']
            
            
            for key,value in d.items():
                if key=="CardHolder_name":
                    CardHolderName=value
                if key=="Card_number":
                    CardNumber=value
                if key=="CardExp_Date":
                    CardExpDate=value
                if key=="Amount":
                    Amount=value
                
        
            c="insert into payment Values('{}','{}','{}','{}')".format(CardHolderName,CardNumber,CardExpDate,Amount)
            cursor.execute(c)
            m.commit()
            return render(request,'paymentSuccessfull.html')
            


    return render(request,'payment.html')  


def contactUs(request):

    global userName,phone,ExplainYourConcern
    if request.method=="POST":
        
        m=mysql.connector.connect(host="localhost",user="root",passwd="root@2201",database='leaf',autocommit=True)
        cursor=m.cursor()
        d=request.POST

        userName=request.POST['user_name']
        phone=request.POST['phone']
        ExplainYourConcern=request.POST['ExplainYourConcern']

        for key,value in d.items():
            if key=="user_name":
                userName=value
            if key=="phone":
                phone=value
            if key=="ExplainYourConcern":
                ExplainYourConcern=value
        
        c="insert into contactUs Values('{}','{}','{}')".format(userName,phone,ExplainYourConcern)
        cursor.execute(c)
        m.commit()
        
       
    return render(request,'contactUs.html')


def paymentSuccessfull(request):
    val1=int(request.POST['Amount'])
    x=val1
    return render(request,'paymentSuccessfull.html',{'paymentSuccessfull':x})


    
                
           
    
    

       
        
            



   
